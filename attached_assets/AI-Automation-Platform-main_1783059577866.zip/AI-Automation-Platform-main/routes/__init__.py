"""HTTP route registration."""
