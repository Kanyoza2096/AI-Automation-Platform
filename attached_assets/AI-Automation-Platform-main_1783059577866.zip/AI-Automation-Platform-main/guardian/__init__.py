"""Code Guardian security scanner."""
