"""Core intelligence modules."""
