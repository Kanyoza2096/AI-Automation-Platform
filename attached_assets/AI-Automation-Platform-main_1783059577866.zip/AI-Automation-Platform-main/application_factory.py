"""
Kanyoza Systems AI Platform v10 — Application Factory.

Creates and configures the Flask application.
Zero business logic lives here — this module only wires middleware,
error handlers, and route blueprints to the Flask app instance.
"""

from __future__ import annotations

import logging
from typing import Optional

from flask import Flask, jsonify, request

from config.settings import Settings
from service_container import ServiceContainer
from utils.ids import set_correlation_id, get_current_correlation_id

logger = logging.getLogger("kanyoza.factory")


def create_app(
    settings: Settings,
    container: ServiceContainer,
    test_config: Optional[dict] = None,
) -> Flask:
    """
    Construct and return a configured Flask application.
    """
    app = Flask(__name__, template_folder="templates", static_folder="static")

    # ------------------------------------------------------------------
    # Flask configuration
    # ------------------------------------------------------------------
    import os
    _secret_key = os.getenv("SESSION_SECRET", "")
    if not _secret_key:
        if settings.env.is_production:
            import sys
            logger.critical(
                "SESSION_SECRET is not set — refusing to start in production."
            )
            sys.exit(1)
        else:
            import secrets
            _secret_key = secrets.token_hex(32)
            logger.warning(
                "SESSION_SECRET not set — using ephemeral key (development only)."
            )

    app.config.update(
        ENV=settings.environment,
        TESTING=settings.env.is_testing,
        SECRET_KEY=_secret_key,
        JSON_SORT_KEYS=False,
        MAX_CONTENT_LENGTH=16 * 1024 * 1024,
    )
    if test_config:
        app.config.update(test_config)

    app.extensions["service_container"] = container

    # ------------------------------------------------------------------
    # Middleware
    # ------------------------------------------------------------------
    _register_request_hooks(app)

    # ------------------------------------------------------------------
    # Error handlers
    # ------------------------------------------------------------------
    _register_error_handlers(app)

    # ------------------------------------------------------------------
    # System routes
    # ------------------------------------------------------------------
    _register_system_routes(app, settings)

    # ------------------------------------------------------------------
    # Application blueprints
    # ------------------------------------------------------------------
    _register_v9_routes(app)
    _register_product_routes(app)

    logger.info("Flask application created (env=%s)", settings.environment)
    return app


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

def _register_request_hooks(app: Flask) -> None:
    @app.before_request
    def assign_correlation_id():
        incoming = request.headers.get("X-Correlation-ID")
        cid = set_correlation_id(incoming)
        request.environ["correlation_id"] = cid

    @app.after_request
    def add_correlation_header(response):
        cid = get_current_correlation_id()
        if cid:
            response.headers["X-Correlation-ID"] = cid
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        return response


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

def _register_error_handlers(app: Flask) -> None:
    from core.exceptions import KanyozaError

    @app.errorhandler(KanyozaError)
    def handle_kanyoza_error(exc: KanyozaError):
        status = getattr(exc, "http_status", 500)
        logger.error("KanyozaError: %s [%s]", exc.message, exc.error_code)
        return jsonify(exc.to_dict()), status

    @app.errorhandler(404)
    def handle_404(exc):
        return jsonify({"error": "NOT_FOUND", "message": "Resource not found."}), 404

    @app.errorhandler(405)
    def handle_405(exc):
        return jsonify({"error": "METHOD_NOT_ALLOWED", "message": "Method not allowed."}), 405

    @app.errorhandler(500)
    def handle_500(exc):
        logger.exception("Unhandled 500 error")
        return jsonify({"error": "INTERNAL_ERROR", "message": "An internal error occurred."}), 500


# ---------------------------------------------------------------------------
# System routes
# ---------------------------------------------------------------------------

def _register_system_routes(app: Flask, settings: Settings) -> None:
    @app.route("/")
    def root():
        return jsonify({
            "service": "Kanyoza Systems AI Platform",
            "version": "10.0",
            "status": "operational",
            "environment": settings.environment,
        })

    @app.route("/health")
    def health():
        return jsonify({
            "status": "healthy",
            "version": "10.0",
            "ai_provider": settings.ai_provider,
            "supabase": settings.supabase_enabled,
        })

    @app.route("/api/v1/status")
    def status():
        return jsonify({
            "version": "10.0",
            "config": settings.to_safe_dict(),
        })

    @app.route("/api/v1/health/deep")
    def health_deep():
        import time
        results = {}
        overall = "ok"

        # Gemini
        gemini_key = getattr(settings, "gemini_key", "") or ""
        if not gemini_key:
            results["gemini"] = {"status": "skip", "reason": "GEMINI_KEY not set"}
        else:
            try:
                from services.gemini import gemini as gemini_svc
                t0 = time.monotonic()
                reply = gemini_svc._call(prompt="Reply with exactly one word: ok", temperature=0.0, max_tokens=8)
                ms = round((time.monotonic() - t0) * 1000)
                results["gemini"] = {"status": "ok", "latency_ms": ms} if reply else {"status": "error", "reason": "empty response"}
            except Exception as exc:
                results["gemini"] = {"status": "error", "reason": str(exc)[:120]}
                overall = "degraded"

        # Facebook
        fb_token = getattr(settings, "page_access_token", "") or ""
        if not fb_token:
            results["facebook"] = {"status": "skip", "reason": "PAGE_ACCESS_TOKEN not set"}
        else:
            try:
                import requests as _req
                t0 = time.monotonic()
                r = _req.get("https://graph.facebook.com/me", params={"fields": "id,name", "access_token": fb_token}, timeout=8)
                ms = round((time.monotonic() - t0) * 1000)
                if r.status_code == 200:
                    data = r.json()
                    results["facebook"] = {"status": "ok", "latency_ms": ms, "page_id": data.get("id"), "page_name": data.get("name")}
                else:
                    results["facebook"] = {"status": "error", "http": r.status_code}
                    overall = "degraded"
            except Exception as exc:
                results["facebook"] = {"status": "error", "reason": str(exc)[:120]}
                overall = "degraded"

        return jsonify({"status": overall, "version": "10.0", "services": results})


# ---------------------------------------------------------------------------
# Route registration
# ---------------------------------------------------------------------------

def _register_v9_routes(app: Flask) -> None:
    """Register v9 bot routes (compatibility shim)."""
    try:
        from routes.webhook import register_webhook_routes
        from routes.api import register_api_routes
        register_webhook_routes(app)
        register_api_routes(app)
        logger.info("v9 routes registered")
    except Exception as exc:
        logger.warning("v9 route registration skipped: %s", exc)


def _register_product_routes(app: Flask) -> None:
    """Register product API blueprints."""
    try:
        from products.converter.routes import converter_bp
        app.register_blueprint(converter_bp)
        logger.info("Converter API registered at /api/v1")
    except Exception as exc:
        logger.warning("Converter blueprint skipped: %s", exc)
